﻿namespace CrudAspNetMvc.Models
{
    public enum EstadoCivil
    {
        Casado,
        Solteiro,
        Divorciado,
        Viuvo
    }
}