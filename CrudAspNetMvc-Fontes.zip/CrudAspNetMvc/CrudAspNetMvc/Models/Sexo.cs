﻿namespace CrudAspNetMvc.Models
{
    public enum Sexo
    {
        Masculino,
        Feminino
    }
}