﻿$(function(){
    $('#txt-cpf').mask('000.000.000-00', { reverse: true });
    $('#txt-telefone').mask('(00) 00000-0000');
});